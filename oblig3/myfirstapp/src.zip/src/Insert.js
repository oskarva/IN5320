import React from "react";

export function Insert() {
  return <h1>Insert</h1>;
}
